#include <random>

namespace INNC {
extern std::mt19937 rng;
}
