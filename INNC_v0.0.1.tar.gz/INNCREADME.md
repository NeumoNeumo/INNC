#  INNC

[![codecov](https://codecov.io/gh/NeumoNeumo/INNC/graph/badge.svg?token=RUKPV0JY33)](https://codecov.io/gh/NeumoNeumo/INNC)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![build](https://github.com/NeumoNeumo/INNC/actions/workflows/ci_meson.yml/badge.svg)](https://github.com/NeumoNeumo/INNC/actions/)

INNC Is Neural Networks in CPP.

Check our [documentation](https://NeumoNeumo.github.io/INNC) for more
information.
