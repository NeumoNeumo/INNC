Manual
============

The foremost class in INNC is ``Tensor``

.. doxygenclass:: INNC::Tensor

