project = 'INNC'
author = 'Jianhui Xu, Chengze Wang, Zijie Wen'
extensions = ["breathe"]

html_theme = 'furo'

breathe_default_project = "INNC"
